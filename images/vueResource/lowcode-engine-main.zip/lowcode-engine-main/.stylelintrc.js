module.exports = {
  extends: 'stylelint-config-ali',
  rules: {
    "selector-max-id": 2
  }
};

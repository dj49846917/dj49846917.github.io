/* eslint-disable @typescript-eslint/no-require-imports */
module.exports = require('../dist/standalone-loader');


const { eslint } = require('@ice/spec');

module.exports = eslint;
    
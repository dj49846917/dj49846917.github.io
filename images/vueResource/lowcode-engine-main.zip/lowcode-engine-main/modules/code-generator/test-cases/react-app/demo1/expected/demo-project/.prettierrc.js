
const { prettier } = require('@ice/spec');

module.exports = prettier;
    
const __$$constants = { ENV: "prod", DOMAIN: "xxx.xxx.com" };

export default __$$constants;

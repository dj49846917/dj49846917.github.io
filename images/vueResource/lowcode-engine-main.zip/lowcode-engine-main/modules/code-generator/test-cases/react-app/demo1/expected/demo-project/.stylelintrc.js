
const { stylelint } = require('@ice/spec');

module.exports = stylelint;
    
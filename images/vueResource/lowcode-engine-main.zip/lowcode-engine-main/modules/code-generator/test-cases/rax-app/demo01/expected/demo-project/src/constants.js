const __$$constants = {};

export default __$$constants;

# rax-materials-basic-app

## Getting Started

### `npm run start`

Runs the app in development mode.

Open [http://localhost:3333](http://localhost:3333) to view it in the browser.

The page will reload if you make edits.

### `npm run build`

Builds the app for production to the `build` folder.

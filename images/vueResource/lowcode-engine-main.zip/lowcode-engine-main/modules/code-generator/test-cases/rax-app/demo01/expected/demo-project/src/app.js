import { runApp } from 'rax-app';

import './global.css';

runApp({
  router: {
    mode: 'hash',
  },
});

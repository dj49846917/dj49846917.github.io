export const REACT_CHUNK_NAME = {
  ClassRenderStart: 'ReactComponentClassRenderStart',
  ClassRenderPre: 'ReactComponentClassRenderPre',
  ClassRenderEnd: 'ReactComponentClassRenderEnd',
  ClassRenderJSX: 'ReactComponentClassRenderJSX',
  ClassDidMountStart: 'ReactComponentClassDidMountStart',
  ClassDidMountEnd: 'ReactComponentClassDidMountEnd',
  ClassDidMountContent: 'ReactComponentClassDidMountContent',
};

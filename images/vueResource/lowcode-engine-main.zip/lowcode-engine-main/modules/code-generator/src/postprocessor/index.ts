import prettier from './prettier';

export { prettier };

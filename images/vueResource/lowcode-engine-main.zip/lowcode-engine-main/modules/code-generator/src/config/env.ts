import * as path from 'path';

export const CODE_GENERATOR_ROOT = path.join(__dirname, '../..');

import createDebug from 'debug';

export const debug = createDebug('code-generator');

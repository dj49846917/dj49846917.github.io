<template>
  <div class="home">
    this is home page
  </div>
</template>

<script>

export default {
  name: 'Home',
  components: {
  }
}
</script>

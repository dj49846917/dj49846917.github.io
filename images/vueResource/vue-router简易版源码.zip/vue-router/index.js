// 1. 插件
// 2. 两个组件

// vue组件：
// function或者object
// 要求必须有一个install, 将来会被Vue.use调用

let Vue; // 保存Vue构造函数，插件中要使用

class VueRouter {
    constructor(options) {
        this.$options = options
        const initial = window.location.hash.split("#")[1] || '/'
        console.log("initial", initial, window.location.hash)
        // 把current作为响应式数据
        // 将来发生变化，router-view的render函数能够再次执行
        Vue.util.defineReactive(this, 'current', initial)
        // 监听hash变化
        window.addEventListener("hashchange", ()=>{
            this.current = window.location.hash.slice(1)
            console.log("this.current", this.current)
        })
    }
}

// 默认会调用install方法
// 蚕食是Vue.use调用时传入的
VueRouter.install = (_Vue) => {
    Vue = _Vue

    // 1. 挂载$router属性
    // this.$router.push
    // 全局混入目的：延迟下面的逻辑到router创建完毕并附加到选项上时才执行
    Vue.mixin({
        beforeCreate() {
            // 此钩子在每个组件创建实例时都会调用
            // 根实例才有该属性
            if(this.$options.router) {
                Vue.prototype.$router = this.$options.router
            }
        }
    })
    // 注册实现两个组件router-view、router-link
    Vue.component('router-link', {
        props: {
            to: {
                type: String,
                required: true,
            }
        },
        render(h) {
            return h('a', { attrs: { href: '#' + this.to } } ,this.$slots.default)
        }
    })

    Vue.component('router-view', {
        render(h) {
            console.log("this.$router.current", this.$router.current)
            // 获取当前路由对应的组件
            let component;
            const route = this.$router.$options.routes.find((route)=>{
                console.log("route", route.path, this.$router.current, route.path === this.$router.current)
                return route.path === this.$router.current
            })
            if(route) {
                component = route.component
            }
            return h(component)
        }
    })
}

export default VueRouter